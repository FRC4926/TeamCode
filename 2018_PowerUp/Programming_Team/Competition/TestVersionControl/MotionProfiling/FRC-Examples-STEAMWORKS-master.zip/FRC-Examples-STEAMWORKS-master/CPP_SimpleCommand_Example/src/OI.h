#ifndef OI_H
#define OI_H

class OI {
public:
	OI();
};

#endif  // OI_H
